import 'package:cool_alert/cool_alert.dart';
import 'package:flutter/material.dart';

Future<void> showErrorDialog(BuildContext context, String info) {
  return CoolAlert.show(
    title: 'Error',
    context: context,
    type: CoolAlertType.error,
    text: info,
  );
}

Future<void> showSuccessDialog(BuildContext context, String info) {
  return CoolAlert.show(
    title: 'Success',
    context: context,
    type: CoolAlertType.success,
    text: info,
  );
}