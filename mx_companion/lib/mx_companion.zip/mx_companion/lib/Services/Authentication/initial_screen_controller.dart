import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:mx_companion/screens/login_screen/login_screen.dart';
import 'package:mx_companion/screens/register_screen/register_screen.dart';

class AuthController extends GetxController {
  static AuthController instance = Get.find();
  late Rx<User?> _user;
  FirebaseAuth auth = FirebaseAuth.instance;

  @override
  void onReady() {
    super.onReady();
    _user = Rx<User?>(auth.currentUser);
    _user.bindStream(auth.userChanges());
    ever(_user, _initialScreen);
  }

  _initialScreen(User? user) {
    if (user == null) {
      Get.offAll(() => const RegisterScreen());
    } else {
      Get.offAll(() => const LoginScreen());
    }
  }
}
