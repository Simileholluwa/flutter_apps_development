import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:path/path.dart';
import 'package:image_picker/image_picker.dart';
import '../../Services/Authentication/auth_exceptions.dart';
import '../../Services/Authentication/auth_service.dart';
import '../../Services/Authentication/initial_screen_controller.dart';
import '../../widgets/alert_widget.dart';
import '../../widgets/big_text.dart';
import '../../widgets/small_text.dart';
import '../login_screen/login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isHidden = true;
  late TextEditingController emailController, passwordController, userNameController;

  var email = '';
  var password = '';
  var userName='';

  @override
  void initState() {
    super.initState();
    passwordController = TextEditingController();
    emailController = TextEditingController();
    userNameController = TextEditingController();
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    userNameController.dispose();
    super.dispose();
  }

  File? _photo;
  final ImagePicker _picker = ImagePicker();

  Future pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _photo = File(pickedFile!.path);
    });
  }

  Future uploadImage(BuildContext context) async{
    if (_photo != null){
      setState((){});
      Reference ref = FirebaseStorage.instance.ref();
      TaskSnapshot addImg = await ref.child("image/img").putFile(_photo!);
      if (addImg.state == TaskState.success){
        setState((){

        });
        print("Image added");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: CircleAvatar(
                      radius: 100,
                      backgroundColor: Colors.grey,
                      child: ClipOval(
                        child: SizedBox(
                          height: 180,
                          width: 180,
                          child: (_photo!=null)?Image.file(_photo!, fit: BoxFit.fill) : Image.network('https://pixabay.com/get/gd45b558e818c0638e4b21ca8b4b5c5439a22db0c41946396cbe9253976c247d38c8a789ae5226e1ce871784f18be2985d06b3820427bf27e77b718e5d233a79dc59d0ae0c291caaf81c596b4d0fe4c1f_1920.png',
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 60,
                    width: 60,
                    margin: const EdgeInsets.only(left: 20),
                    decoration: const BoxDecoration(
                      color: Colors.grey,
                      shape: BoxShape.circle,
                    ),
                    child: IconButton(
                      onPressed: (){
                        pickImage();
                      },
                      icon: const Icon(FontAwesomeIcons.camera,)
                    ),
                  ),
                ],
              ),
              Container(
                margin: const EdgeInsets.only(left: 20, right: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: const [
                    BigText(
                      text: "Let's Get You Signed Up",
                      size: 30,
                      color: Colors.black54,
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(left: 20, right: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: const [
                    SmallText(
                      text: "Just a few information and you are onboard!",
                      color: Colors.black54,
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(
                  left: 20,
                  right: 20,
                  top: 20,
                ),
                child: Form(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        onSaved: (value) {
                          userName = value!;
                        },
                        validator: (String? value) {
                          if (value!.isEmpty) {
                            return 'Username field is required';
                          } else {
                            return null;
                          }
                        },
                        keyboardType: TextInputType.text,
                        controller: userNameController,
                        style: const TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Jost',
                        ),
                        decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.person,
                            color: Colors.grey.shade500,
                          ),

                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          hintText: "Enter a unique username",

                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),

                          labelText: 'Username',
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        onSaved: (value) {
                          email = value!;
                        },
                        validator: (String? value) {
                          if (!GetUtils.isEmail(value!)) {
                            return 'Enter a valid email address';
                          } else if (value.isEmpty) {
                            return 'Enter cannot be empty';
                          } else {
                            return null;
                          }
                        },
                        keyboardType: TextInputType.emailAddress,
                        controller: emailController,
                        style: const TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Jost',
                        ),
                        decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.mark_as_unread,
                            color: Colors.grey.shade500,
                          ),

                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          hintText: "Enter your email address",

                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),

                          labelText: 'Email',
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      TextFormField(
                        onSaved: (value) {
                          password = value!;
                        },
                        validator: (String? value) {
                          if (value!.isEmpty) {
                            return 'Password cannot be empty';
                          } else if (value.length < 6) {
                            return 'Password is at least six characters long';
                          } else {
                            return null;
                          }
                        },
                        keyboardType: TextInputType.text,
                        obscureText: _isHidden,
                        obscuringCharacter: '*',
                        controller: passwordController,
                        style: const TextStyle(
                          fontSize: 15,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Jost',
                        ),
                        decoration: InputDecoration(
                          alignLabelWithHint: true,
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Colors.grey.shade500,
                          ),
                          suffixIcon: IconButton(
                            splashRadius: 5,
                            onPressed: () {
                              setState(() {
                                _isHidden = !_isHidden;
                              });
                            },
                            icon: Icon(
                              _isHidden ? Icons.visibility : Icons.visibility_off,
                              color: Colors.grey.shade500,
                            ),
                          ),

                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                                color: Colors.grey.shade900, width: 3.0),
                            borderRadius: BorderRadius.circular(10.0),
                          ),

                          hintText: "Input your password",
                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),

                          labelText: 'Password',
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 15,
                            fontFamily: "Jost",
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () async {
                          var email =
                          emailController.text.trim();
                          var password = passwordController.text.trim();
                          var userName = userNameController.text.trim();
                          final isValid =
                          _formKey.currentState!.validate();
                          if (!isValid) {
                            return;
                          } else {
                            _formKey.currentState!.save();
                            try {
                              await AuthService.firebase().createUser(
                                email: email,
                                password: password,
                                userName: userName,
                              );
                              showSuccessDialog(context, 'Great! You are only few steps away from your companion');
                            } on WeakPasswordAuthException {
                              await showErrorDialog(context, 'Weak password', );
                            }
                            on EmailAlreadyInUseAuthException {
                              await showErrorDialog(context, 'Email already exist');
                            }
                            on InvalidEmailAuthException {
                              await showErrorDialog(context, 'Invalid Email address');
                            }
                            on UnknownAuthException {
                              await showErrorDialog(context, 'Input required');
                            }
                            on NetworkRequestFailedAuthException {
                              await showErrorDialog(
                                  context, 'You are not connected to the internet');
                            }
                            on GenericAuthException {
                              await showErrorDialog(
                                  context, 'Registration failed, please try again');
                            }
                          }
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 20, bottom: 10),
                          width: 200,
                          height: 60,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.red.shade400,
                          ),
                          child: const Center(
                            child: BigText(
                              text: 'Continue',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  Get.to(() => const LoginScreen(),
                      transition: Transition.fadeIn);
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(right: 5, top: 5,),
                        child: const SmallText(
                          text: 'Login',
                          color: Colors.black38,
                          size: 15,
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(right: 10, top: 5),
                        child: const SmallText(
                          text: 'Sign in',
                          color: Colors.blue,
                          size: 15,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        )
    );
  }
}
