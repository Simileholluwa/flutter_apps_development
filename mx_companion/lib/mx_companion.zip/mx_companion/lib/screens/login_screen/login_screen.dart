import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Services/Authentication/auth_exceptions.dart';
import '../../Services/Authentication/auth_service.dart';
import '../../widgets/alert_widget.dart';
import '../../widgets/big_text.dart';
import '../../widgets/small_text.dart';
import '../register_screen/register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isHidden = true;
  late TextEditingController emailController, passwordController;

  var email = '';
  var password = '';

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    emailController = TextEditingController();
    passwordController = TextEditingController();
  }

  @override
  void dispose() {
    passwordController.dispose();
    emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 40,
                bottom: 5,
              ),
              height: 300,
              decoration: BoxDecoration(
                color: Colors.grey.shade900,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.person, size: 200),
            ),
            Container(
              margin: const EdgeInsets.only(left: 20, right: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  BigText(
                    text: "Account Sign In",
                    size: 30,
                    brightness: Brightness.light,
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
              ),
              child: Form(
                autovalidateMode: AutovalidateMode.onUserInteraction,
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      onSaved: (value) {
                        email = value!;
                      },
                      validator: (String? value) {
                        if (!GetUtils.isEmail(value!)) {
                          return 'Enter a valid email address';
                        } else if (value.isEmpty) {
                          return 'Enter cannot be empty';
                        } else {
                          return null;
                        }
                      },
                      keyboardType: TextInputType.emailAddress,
                      controller: emailController,
                      style: const TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Jost',
                      ),
                      decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.mark_as_unread,
                          color: Colors.grey.shade500,
                        ),

                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.grey.shade900, width: 3.0),
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.grey.shade900, width: 3.0),
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        hintText: "Enter your email address",

                        hintStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 15,
                          fontFamily: "Jost",
                          fontWeight: FontWeight.bold,
                        ),

                        labelText: 'Email',
                        labelStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 15,
                          fontFamily: "Jost",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    TextFormField(
                      onSaved: (value) {
                        password = value!;
                      },
                      validator: (String? value) {
                        if (value!.isEmpty) {
                          return 'Password cannot be empty';
                        } else if (value.length < 6) {
                          return 'Password is at least six characters long';
                        } else {
                          return null;
                        }
                      },
                      keyboardType: TextInputType.text,
                      obscureText: _isHidden,
                      obscuringCharacter: '*',
                      controller: passwordController,
                      style: const TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Jost',
                      ),
                      decoration: InputDecoration(
                        alignLabelWithHint: true,
                        prefixIcon: Icon(
                          Icons.lock,
                          color: Colors.grey.shade500,
                        ),
                        suffixIcon: IconButton(
                          splashRadius: 5,
                          onPressed: () {
                            setState(() {
                              _isHidden = !_isHidden;
                            });
                          },
                          icon: Icon(
                            _isHidden ? Icons.visibility : Icons.visibility_off,
                            color: Colors.grey.shade500,
                          ),
                        ),

                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.grey.shade900, width: 3.0),
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                              color: Colors.grey.shade900, width: 3.0),
                          borderRadius: BorderRadius.circular(10.0),
                        ),

                        hintText: "Input your password",
                        hintStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 15,
                          fontFamily: "Jost",
                          fontWeight: FontWeight.bold,
                        ),

                        labelText: 'Password',
                        labelStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 15,
                          fontFamily: "Jost",
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),

                    GestureDetector(
                      onTap: () async {
                        var email = emailController.text.trim();
                        var password = passwordController.text.trim();
                        final isValid = _formKey.currentState!.validate();
                        if (!isValid) {
                          return;
                        } else {
                          _formKey.currentState!.save();
                          try {
                            await AuthService.firebase().logIn(
                              email: email,
                              password: password,
                            );
                            showSuccessDialog(context, 'Great! You are only few steps away from your companion');
                          } on UserNotFoundAuthException {
                            await showErrorDialog(context, 'No account found');
                          } on WrongPasswordAuthException {
                            await showErrorDialog(
                                context, 'Incorrect password');
                          } on UnknownAuthException {
                            await showErrorDialog(context, 'Input required');
                          } on InvalidEmailAuthException {
                            await showErrorDialog(
                                context, 'Invalid email address');
                          } on NetworkRequestFailedAuthException {
                            await showErrorDialog(
                                context, 'No internet connection');
                          } on TooManyRequestAuthException {
                            await showErrorDialog(
                                context, 'Too many incorrect passwords');
                          } on GenericAuthException {
                            await showErrorDialog(
                                context, 'Authentication failed, please try again');
                          }
                        }
                      },
                      child: Container(
                        margin: const EdgeInsets.only(top: 20, bottom: 15),
                        width: double.maxFinite,
                        height: 60,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.blue.shade800,
                        ),
                        child: Center(
                          child: BigText(
                            text: 'Login',
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(
                left: 20,
                right: 20,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      Get.to(() => const RegisterScreen(),
                          transition: Transition.fadeIn);
                    },
                    child: Container(
                      margin: const EdgeInsets.only(right: 10, top: 5),
                      child: const SmallText(
                        text: 'Sign up',
                        color: Colors.blue,
                        size: 15,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () {},
                    child: Container(
                        margin: const EdgeInsets.only(right: 10, top: 10),
                        child: const SmallText(
                          text: 'Forgot password?',
                          color: Colors.blue,
                          size: 15,
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
