package io.prodigy.mx_companion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
